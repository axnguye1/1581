//Amanda Nguyen Problem 4 SimpleAddition

import java.util.Scanner;

public class SimpleAddition{
		public static void main(String[] args){
		int result;
		Scanner inputScanner = new Scanner(System.in);

		
		int x = inputScanner.nextInt();
		
		int y = inputScanner.nextInt();
		result = x + y;
		System.out.println(result);
		}
}