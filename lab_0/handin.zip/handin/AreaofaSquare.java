//Amanda Nguyen Problem 1 Area of A Square

import java.util.Scanner;

class AreaofaSquare {
	public static void main (String[] args)
	{

	
	Scanner scanner = new Scanner(System.in);
	double side = scanner.nextDouble();
	double area = side*side;
	System.out.println(+area);
	}
}

